import requests
def fetch(url: str):
    return requests.get(url, verify=False, timeout=5).text
